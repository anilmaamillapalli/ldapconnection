package org.sh.custom.nonemp;

import com.csvreader.CsvReader;
import com.csvreader.CsvWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;

import java.nio.file.Path;

import java.nio.file.Paths;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.swing.JOptionPane;

import oracle.core.ojdl.logging.ODLLevel;
import oracle.core.ojdl.logging.ODLLogger;

import oracle.iam.identity.exception.NoSuchUserException;
import oracle.iam.identity.exception.UserModifyException;
import oracle.iam.identity.exception.ValidationFailedException;
import oracle.iam.identity.usermgmt.api.UserManager;
import oracle.iam.identity.usermgmt.vo.User;
import oracle.iam.identity.usermgmt.vo.UserManagerResult;
import oracle.iam.platform.Platform;
import oracle.iam.scheduler.vo.TaskSupport;

/****************************************************************************************************
 * Project Name         : Spectrum Health
 * Copyright            : TDC
 * Company              : TDC
 * Version              : 1.0
 * File Name            : SHEndDateExtenstion
 * Environment          : OIM 11g R2 PS3
 * Description/Purpose  : This schedule task is used to update Non Employees end date.
 * Implement            :
 * Extends              : TaskSupport
 * Modified Details     :
 * Ver. No.             Modified by                  Date                Why & What is modified
 *
 * 1.0                  Anil Maamillapalli(MAK)      24-Nov-2018             INITIAL
 *
 *******************************************************************************************************/
public class NonEmpEndDateExtend extends TaskSupport{
    public NonEmpEndDateExtend() {
        super();
    }
    private static final ODLLogger logger=ODLLogger.getODLLogger(NonEmpEndDateExtend.class.getName());
    private boolean isUserEndDate;
    private boolean isSystemDate;
    private String outputFilePath;
    private String csvFilePath;
    private String outFile;
    private String archiveFolderPath;
    
    /***************************************************************************
     *Description   :This is Main Method to execute 
     * @param       hashMap
     * 
     * @return      void 
    **************************************************************************/
  public void execute(HashMap hashMap) throws FileNotFoundException {
        
        logger.entering("==NonEmpEndDateExtend==> ","execute {0}", new Object[]{hashMap}[0]);
       // logger.log(ODLLevel.NOTIFICATION, "Entered execute(HashMap hashMap)with Parameters:", new Object[]{hashMap}[0]);
        csvFilePath=((String)hashMap.get("Absolute_CSV_File_Path")).trim();
        logger.log(ODLLevel.NOTIFICATION,"Absolute CSV File Path in OIG",new Object[]{csvFilePath}[0]);
        archiveFolderPath=((String)hashMap.get("Absolute_Archive_Folder_Path")).trim();
        logger.log(ODLLevel.NOTIFICATION,"Absolute archive folder Path", new Object[]{archiveFolderPath}[0]);
        int noOfDays=((Long)hashMap.get("Days")).intValue();
        logger.log(ODLLevel.NOTIFICATION,"Total Number of Days to be Extend are :",new Object[]{noOfDays});
        isUserEndDate=(Boolean)hashMap.get("Extend_From_User_End_Date");
        logger.log(ODLLevel.NOTIFICATION,"Extend End Date From User End date ?:", new Object[]{isUserEndDate}[0]);
        isSystemDate=(Boolean)hashMap.get("System_Date");
        logger.log(ODLLevel.NOTIFICATION,"Extend User End Date From System Date ?:", new Object[]{isSystemDate}[0]);
        outputFilePath=(String)hashMap.get("Absolute_Error_Output_File_Path");
        logger.log(ODLLevel.NOTIFICATION,"Absulate File path for Errors",new Object[]{outputFilePath}[0]);
        
        
        if(csvFilePath.contains(".csv")){
               if(noOfDays > 1 && noOfDays <= 365  ){
                   if(isUserEndDate){
                       extendEndDate(csvFilePath,noOfDays);
                   }else if(isSystemDate){
                        extendEndDate( csvFilePath,noOfDays);
                    }else{
                        throw new IllegalStateException("Please select 'FROM USER END DATE' or 'FROM SYSTEM DATE'");
                    }
              }else{
                   throw new IllegalStateException("Total number of days should be > 1 and <= 365"); 
              }
        }else{
             throw new FileNotFoundException(csvFilePath+".csv File Not found");
        }
        logger.exiting("NonEmpEndDateExtend", "<==execute==");
    }
    
    /***************************************************************************
     *Description   :This is Main Method to infoBox (this method not used) 
     * @param       String,String
     * 
     * @return      void 
    **************************************************************************/
    
    private static void infoBox(String infoMessage,String titleBar){
        logger.log(ODLLevel.NOTIFICATION,"Entered into==> infoBox(String infoMessage,String titleBar)", new Object[]{infoMessage,titleBar}[0]);
        JOptionPane.showMessageDialog(null, infoMessage, "InfoBox: " + titleBar, JOptionPane.INFORMATION_MESSAGE);
    }

    /***************************************************************************
     *Description   :This is Main Method to getNewEndDate
     * @param       :Date,int
     * 
     * @return      :Date 
    **************************************************************************/
    private static Date getNewEndDate(Date userEndDate,int days)  {
        logger.entering("==NonEmpEndDateExtend==>", "==getNewEndDate=={0}",new Object[]{userEndDate,days}[0]);
        logger.entering("==NonEmpEndDateExtend==>", "==getNewEndDate=={1}",new Object[]{userEndDate,days}[1]);
          
      //  logger.log(ODLLevel.NOTIFICATION,"Entered Into getNewEndDate(Date userEndDate,int days)",new Object[]{userEndDate,days}[0]);
            SimpleDateFormat sFormat= new SimpleDateFormat(EndDateConstants.DATETIME);
            Calendar calendar=Calendar.getInstance();
            calendar.setTime(userEndDate);
            calendar.add(Calendar.DATE,days);
            calendar.add(Calendar.HOUR,23);
            calendar.add(Calendar.MINUTE,59);
            calendar.add(Calendar.SECOND,59);
            String strDate=sFormat.format(calendar.getTime());
            SimpleDateFormat sqlFormat= new SimpleDateFormat(EndDateConstants.DATETIME);
            Date parse=null;
            try {
                parse = sqlFormat.parse(strDate);
            } catch (ParseException e) {
                logger.log(ODLLevel.ERROR,e.getMessage(),new Object[]{e});
            }
            Date sqlDate= new Date(parse.getTime());
            logger.exiting("NonEmpEndDateExtend", "<==getNewEndDate==",new Object[]{sqlDate}[0]);
            return  sqlDate;
        }
     
    /***************************************************************************
     *Description   :This is Main Method to getFormatedDate
     * @param       :java.util.Date
     * 
     * @return      :java.util.Date
    **************************************************************************/
    public static Date getFormatedDate(String sDate)  {
        logger.entering("==NonEmpEndDateExtend==>", "getFormatedDate{0}", new Object[]{sDate}[0]);
       // logger.log(ODLLevel.NOTIFICATION,"Entered Into getFormatedDate(String sDate)", new Object[]{sDate}[0]);
           Date formatedDate= null;
           SimpleDateFormat sdFormat= new SimpleDateFormat(EndDateConstants.DATESTRING);
            try {
                 formatedDate = sdFormat.parse(sDate);
                } catch (ParseException e) {
                    logger.log(ODLLevel.ERROR,e.getMessage(),new Object[]{e});
                }
            logger.exiting("NonEmpEndDateExtend", "<==getFormatedDate==",new Object[]{formatedDate}[0]);
            return formatedDate;
        }
    
    /***************************************************************************
     *Description   :This is Main Method to getFormatedDate
     * @param       :java.lang.String, int
     * 
     * @return      : void
    **************************************************************************/
     private void extendEndDate(String csvFilePath, int noOfDays) {
           logger.entering("==NonEmpEndDateExtend==>", "getFormatedDate{0}", new Object[]{csvFilePath}[0]);
           logger.entering("==NonEmpEndDateExtend==>", "getFormatedDate{1}", new Object[]{noOfDays}[1]);
        //logger.log(ODLLevel.NOTIFICATION,"Entered Into extendEndDate(String csvFilePath, int noOfDays)", new Object[]{csvFilePath,noOfDays}[0]);
            CsvReader enduserDates=null;
            outFile=EndDateConstants.OUTPUTFILE_NAME+System.currentTimeMillis()/3600;
            outputFilePath= outputFilePath+outFile+".csv";
            logger.log(ODLLevel.NOTIFICATION,"New Output Error absolute file path", new Object[]{outFile}[0]);
            boolean alreadyExists = new File(outputFilePath).exists();
            CsvWriter csvOutput=null;
            try {
                csvOutput = new CsvWriter(new FileWriter(outputFilePath, true), ',');
                    if(!alreadyExists){
                        csvOutput.write(EndDateConstants.HEADER_INDEX);
                        csvOutput.write(EndDateConstants.COLUMN_USR_KEY);
                        csvOutput.write(EndDateConstants.COLUMN_USR_END_DATE);
                        csvOutput.write(EndDateConstants.COLUMN_USR_LOGIN);
                        csvOutput.write(EndDateConstants.COLUMN_ERROR_INFO);
                        csvOutput.endRecord();
                }
        } catch (IOException e) {
            logger.log(ODLLevel.ERROR,e.getMessage(),new Object[]{e.getMessage()}[0]);
        }
         int index =1; 
        try {
            enduserDates = new CsvReader(csvFilePath);
            enduserDates.readHeaders();
            while(enduserDates.readRecord()){
                
                if(((String)enduserDates.get(EndDateConstants.COLUMN_USR_EMP_TYPE)).equalsIgnoreCase("EMP")){
                       csvOutput.write((Integer.toString(index++)));
                       csvOutput.write(enduserDates.get(EndDateConstants.COLUMN_USR_KEY));
                       csvOutput.write(enduserDates.get(EndDateConstants.COLUMN_USR_END_DATE));
                       csvOutput.write(enduserDates.get(EndDateConstants.COLUMN_USR_LOGIN));
                       csvOutput.endRecord();                                           
                    
                }else{
                    User user=new User(enduserDates.get(EndDateConstants.COLUMN_USR_KEY));
                      if(isUserEndDate){
                          user.setAttribute("End Date", getNewEndDate(new Date(),noOfDays));
                      }else if(isSystemDate){
                          String isUserEndDate=enduserDates.get(EndDateConstants.COLUMN_USR_END_DATE);
                          if(isUserEndDate !=null && !isUserEndDate.isEmpty()){
                              user.setAttribute(EndDateConstants.ENDDATE,getNewEndDate(getFormatedDate(enduserDates.get(EndDateConstants.COLUMN_USR_END_DATE)),noOfDays));
                          }else{
                              user.setAttribute(EndDateConstants.ENDDATE, getNewEndDate(new Date(),noOfDays));
                          }
                      }
                      user.setAttribute(EndDateConstants.USR_DEPROVISIONING_DATE, null);
                     // user.setAttribute(EndDateConstants.SH_TERM_DATE, null);
                      UserManagerResult userMgrResult= null;
                      try {
                         userMgrResult = Platform.getService(UserManager.class).modify(user);
                         logger.log(ODLLevel.NOTIFICATION,"Non Employee "+enduserDates.get(EndDateConstants.COLUMN_USR_LOGIN)+ "`s"+"End Date was successfully updated==>"+"::", new Object[]{userMgrResult}[0]);                   
                      } catch (ValidationFailedException e) {
                          csvOutput.write((Integer.toString(index++)));
                          csvOutput.write(enduserDates.get(EndDateConstants.COLUMN_USR_KEY));
                          csvOutput.write(enduserDates.get(EndDateConstants.COLUMN_USR_END_DATE));
                          csvOutput.write(enduserDates.get(EndDateConstants.COLUMN_USR_LOGIN));
                          csvOutput.write(e.getMessage());
                          csvOutput.endRecord();
                          logger.log(ODLLevel.ERROR,e.getMessage(),new Object[]{e.getMessage()}[0]);
                      } catch (UserModifyException e) {
                          csvOutput.write((Integer.toString(index++)));
                          csvOutput.write(enduserDates.get(EndDateConstants.COLUMN_USR_KEY));
                          csvOutput.write(enduserDates.get(EndDateConstants.COLUMN_USR_END_DATE));
                          csvOutput.write(enduserDates.get(EndDateConstants.COLUMN_USR_LOGIN));
                          csvOutput.write(e.getMessage());
                          csvOutput.endRecord();
                          logger.log(ODLLevel.ERROR,e.getMessage(),new Object[]{e.getMessage()}[0]);
                      } catch (NoSuchUserException e) {
                          csvOutput.write((Integer.toString(index++)));
                          csvOutput.write(enduserDates.get(EndDateConstants.COLUMN_USR_KEY));
                          csvOutput.write(enduserDates.get(EndDateConstants.COLUMN_USR_END_DATE));
                          csvOutput.write(enduserDates.get(EndDateConstants.COLUMN_USR_LOGIN));
                          csvOutput.write(e.getMessage());
                          csvOutput.endRecord();
                          logger.log(ODLLevel.ERROR,e.getMessage(),new Object[]{e.getMessage()}[0]);
                      }
                 }
             // String userKey=enduserDates.get(EndDateConstants.COLUMN_USR_KEY);
            } 
            csvOutput.close();
            } catch (FileNotFoundException e) {
            logger.log(ODLLevel.ERROR,e.getMessage(),new Object[]{e.getMessage()}[0]);
            } catch (IOException e) {
            logger.log(ODLLevel.ERROR,e.getMessage(),new Object[]{e.getMessage()}[0]);
            }finally{
                archiveFile(csvFilePath);
            }
           logger.exiting("NonEmpEndDateExtend", "<==extendEndDate==");
       // logger.log(ODLLevel.NOTIFICATION,"Exiting From extendEndDate(String csvFilePath, int noOfDays)");
       }
    public HashMap getAttributes() {
        return null;
    }
   public void setAttributes() {
    }
  private void archiveFile(String csvFilePath){
       logger.entering("==NonEmpEndDateExtend==>", "archiveFile{0}", new Object[]{csvFilePath}[0]);
     //  logger.log(ODLLevel.NOTIFICATION,"Entered Into archiveFile(String csvFilePath)",new Object[]{csvFilePath}[0]);
     File filePath= null;
        try {
          
          archiveFolderPath=archiveFolderPath+outFile+".zip";
            FileOutputStream fos = new FileOutputStream(archiveFolderPath);
            ZipOutputStream zos = new ZipOutputStream(fos);
            filePath=new File(csvFilePath);
            FileInputStream in = new FileInputStream(csvFilePath);
            zos.putNextEntry(new ZipEntry(filePath.getName()));
             byte[] b = new byte[1024];
          int count;
            while ((count = in.read(b)) > 0){
              zos.write(b, 0, count);
            }
            zos.close();
            in.close();
        } catch (FileNotFoundException e) {
            logger.log(ODLLevel.ERROR,e.getMessage(),new Object[]{e}[0]);
        } catch (IOException e) {
            logger.log(ODLLevel.ERROR,e.getMessage(),new Object[]{e}[0]);
        }finally{
             filePath.deleteOnExit();     
        }
       logger.exiting("NonEmpEndDateExtend", "<==archiveFile=="); 
   }

}