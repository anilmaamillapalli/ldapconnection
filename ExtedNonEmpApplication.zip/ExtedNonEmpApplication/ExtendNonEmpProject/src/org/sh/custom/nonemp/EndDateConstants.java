package org.sh.custom.nonemp;

public class EndDateConstants {
    
    public static final String DATETIME="dd/MM/yyyy hh:mm:ss";
    public static final String DATESTRING="dd-MMM-yyyy";
    public static final String HEADER_INDEX="INDEX";
    public static final String COLUMN_USR_KEY="USR_KEY";
    public static final String COLUMN_USR_END_DATE="USR_END_DATE";
    public static final String COLUMN_USR_LOGIN="USR_LOGIN";
    public static final String COLUMN_ERROR_INFO="ERROR_INFO"; 
    public static final String COLUMN_USR_STATUS="USR_STATUS";
    public static final String COLUMN_USR_EMP_TYPE="USR_EMP_TYPE";
    public static final String ENDDATE="End Date";  
    public static final String USR_DEPROVISIONING_DATE="usr_deprovisioning_date";
    public static final String SH_TERM_DATE="TERM_DATE"; 
    public static final String NO_DAYS="Either Input file or  No of Days to Extend are missing,please provide Input file and days should be grater then 1 and less then 365";
    public static final String EXTEND_FORM="Please check USER END DATE or SYSDATE  to trigger program";
    public static final String OUTPUTFILE="Please provide File path to Save error Information";
    public static final String OUTPUTFILE_NAME="NonEmpEndDateFile";
                            
}
